<?php
include('../includes/header.php');
?>
<style>
   body {
      margin: 150px;
      text-align: center;
      margin-top: 50px;
   }

   .container {
      border-style: solid;
      border-radius: 5px;
      border-color: aqua;
      margin: 50px;
   }

   .row {
      margin: 10px;
   }

   .form {
      margin: 20px;
   }
</style>

<body>


   <h1>Staff Register</h1>
   <form action="" method="post">
      <div class="form">
         <input type="text" name="staff_id" placeholder="Staff_id" required>
      </div>
      <div class="form">
         <input type="text" name="username" placeholder="username" required>
      </div>
      <div class="form">
         <input type="password" name="password" minlength="6" placeholder="password" required>
      </div>
      <div class="form">
         <input type="password" name="con_password" placeholder="Confirm password" required>
      </div>
      <div class="form">

         <button class="btn btn-primary" type="submit" name="update">Submit</button>
      </div>

   </form>

   <?php

   if (isset($_POST['update'])) {
      $get_id =  $_POST['staff_id'];
      $username =  $_POST['username'];
      $password =  $_POST['password'];
      $con_password =  $_POST['con_password'];

      if ($password === $con_password) {
         $query = "UPDATE staff SET ";
         $query .= "username  = '{$username}', ";
         $query .= "password  = '{$password}' ";
         $query .= "WHERE staff_id = {$get_id} ";

         $update_query = mysqli_query($conn, $query);

         echo "<p style='background-color:green;' class='text-white p-3'> Record was successfully you can now login</p>";
         echo "<a href='../index.php'>login</a>";
         if (!$update_query) {
            die("Query failed" . mysqli_error($conn));
         }
      } else {
         echo "<p class='alert alert-danger text-white p-3'> Password did not match</p>";
      }
   }


   ?>


</body>

</html>
<?php
include('../includes/header.php');


?>
<style>
   body {
      margin: 150px;
      text-align: center;
      margin-top: 50px;
   }

   .container {
      border-style: solid;
      border-radius: 5px;
      border-color: aqua;
      margin: 50px;
   }

   .row {
      margin: 10px;
   }

   .form {
      margin: 20px;
   }
</style>

<body>

   <?php
   session_start();
   $sql = "SELECT * FROM staff WHERE staff_id = {$_SESSION['staff_id']}";
   $result = $conn->query($sql);

   if ($result->num_rows > 0) {
      // output data of each row
      while ($row = $result->fetch_assoc()) {
         $staff_id = $row["staff_id"];
         $full_names = $row["full_names"];
      }
   }
   ?>

   <h1>Staff Panel</h1>
   <h6 class="text-danger">Name : <?php echo $full_names;  ?> </h6>
   <hr>
   <?php include('staff_nav.php'); ?>

   <hr>
   <h4>Pending leaves</h4>

   <table class="table table-bordered" style="width:100%">
      <tr>
         <th>Leave ID</th>
         <th>Type of leave</th>
         <th>Description</th>
         <th>Date From</th>
         <th>Date to</th>
         <th>Status</th>
      </tr>
      <?php
      $sql = "SELECT * FROM leaves ORDER BY leave_id DESC";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
         // output data of each row
         while ($row = $result->fetch_assoc()) {
            $leave_id = $row["leave_id"];
            $type_of_leave = $row["type_of_leave"];
            $description = $row["description"];
            $date_from = $row["date_to"];
            $date_to = $row["date_to"];
            $status = $row["status"];

            // echo $staff_id;

      ?>
            <tr>
               <td> <?php echo $leave_id; ?> </td>
               <td><?php echo $type_of_leave; ?> </td>
               <td><?php echo $description; ?> </td>
               <td><?php echo $date_from;  ?> </td>
               <td><?php echo $date_to; ?> </td>
               <?php
               if ($status === "pending") {
                  echo " <td> <p class='alert alert-warning text-dark'> $status </p> </td>";
               } elseif ($status === "rejected") {
                  echo " <td> <p class='alert alert-danger text-dark'> $status </p> </td>";
               } else {
                  echo " <td> <p class='alert alert-success text-dark'> $status </p> </td>";
               }

               ?>

            </tr>





      <?php

            // echo "id: " . $row["staff_id"] . " - Name: " . $row["firstname"] . " " . $row["lastname"] . "<br>";
         };
      } else {
         echo "0 results";
      }
      $conn->close();


      ?>

   </table>

</body>

</html>
<ul class="nav justify-content-center">
   <li class="nav-item">
      <a class="btn btn-outline-danger text-dark m-3" href="index.php">Apply</a>
   </li>
   <li class="nav-item">
      <a class="btn btn-outline-danger text-dark m-3" href="view _leave.php">Status</a>
   </li>
   <li class="nav-item">
      <a class="btn btn-outline-danger text-dark m-3" href="#">Reports</a>
   </li>
   <li class="nav-item">
      <a class="btn btn-danger text-white m-3" href="#">Logout</a>
   </li>
</ul>
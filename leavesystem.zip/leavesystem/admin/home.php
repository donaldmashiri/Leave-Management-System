<?php
include('../includes/header.php');


?>
<style>
   body {
      margin: 150px;
      text-align: center;
      margin-top: 50px;

   }

   h4 {
      background-color: red;
      color: white;
   }

   .box {
      border-style: solid;
      border-radius: 5px;
      border-color: aqua;
   }
</style>

<body>
   <?php include '../includes/nav.php' ?>

   <h1 class="text-center">Add Staff</h1>

   <?php
   if (isset($_POST['submit'])) {
    
            $full_names = $_POST['full_names'];
            $email = $_POST['email'];
            $gender = $_POST['gender'];
            $position = $_POST['position'];

            // echo $full_names;


            $sql = "INSERT INTO staff (full_names, gender, email, position)
      VALUES ('{$full_names}', '{$email}', '{$gender}','{$position}')";

            if ($conn->query($sql) === TRUE) {
         echo "<p style='background-color:green;' class='text-white p-3'> New record created successfully</p>";
            } else {
               echo "Error: " . $sql . "<br>" . $conn->error;
            }
   }


   ?>


   <br>
   <form action="" method="post">
      <div class="form-group">
         <input type="text" class="form-control" name="full_names" placeholder="full names">
      </div>
      <div class="form-group">
         <input type="email" class="form-control" name="email" placeholder="Email">
      </div>
      <div class="form-group">
         <input type="Gender" class="form-control" name="gender" placeholder="Gender">
      </div>
      <div class="form-group">
         <input type="text" class="form-control" name="position" placeholder="Staff position">
      </div>
      <div class="form-group">
         <!-- <a href="staff/index.html">Submit</a> -->
         <button class="btn btn-primary btn-block" type="submit" name="submit">Submit</button>
      </div>
   </form>



</body>

</html>
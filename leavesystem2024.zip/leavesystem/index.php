<?php include('includes/db.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login</title>
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <style>
      body {
         margin: 150px;
         text-align: center;
         margin-top: 50px;
      }

      .container {
         border-style: solid;
         border-radius: 5px;
         border-color: aqua;
         margin: 50px;
      }

      .row {
         margin: 10px;
      }

      .form {
         margin: 20px;
      }
   </style>

<body>

   <h1 class="text-center">Staff Login</h1>


   <form action="" method="post">
      <div class="form">
         <input type="text" name="username" placeholder="username">
      </div>
      <div class="form">
         <input type="password" name="password" placeholder="password">
      </div>
      <div class="form">
         <button type="submit" name="signin" class="btn btn-primary text-right">Login</button>
      </div>
      <div class="form">
         <a href="staff/new-user.php">New staff member</a>
      </div>
   </form>





   <?php

   if (isset($_POST['signin'])) {
     

      $username =  $_POST['username'];
      $password =  $_POST['password'];

      $query = mysqli_query($conn, "SELECT staff_id FROM staff WHERE username ='$username' and password = '$password'");
      $numrows = mysqli_num_rows($query);

      if ($numrows >= 1) {
         $row = mysqli_fetch_array($query);
         $_SESSION['staff_id'] = $row['staff_id'];
         header('location:staff/index.php');
      } else {
   ?>
         <script>
            alert('Incorrect details');
            header('location:index.php');
         </script>
   <?php
      }
   }

   ?>




</body>

</html>
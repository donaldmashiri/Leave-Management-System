 <div class="row">
   Supervisor Side
 </div>
 
 <ul class="nav justify-content-center">
    <!-- <li class="nav-item">
       <a class="btn btn-outline-primary text-dark m-3" href="home.php">Add Staff</a>
    </li> -->
    <li class="nav-item">
       <a class="btn btn-outline-primary text-dark m-3" href="view_staff.php">View Staff</a>
    </li>
    <li class="nav-item">
       <a class="btn btn-outline-warning text-dark  m-3" href="view_leaves.php">Pending Applications</a>
    </li>
    <li class="nav-item">
       <a class="btn btn-outline-danger text-dark m-3" href="reports.php">Reports</a>
    </li>
 </ul>
<?php
include('../includes/header.php');


?>
<style>
   body {
      margin: 150px;
      text-align: center;
      margin-top: 50px;
   }

   .container {
      border-style: solid;
      border-radius: 5px;
      border-color: aqua;
      margin: 50px;
   }

   .row {
      margin: 10px;
   }

   .form {
      margin: 20px;
   }
</style>

<body>

   <?php

   $sql = "SELECT * FROM staff WHERE staff_id = {$_SESSION['staff_id']}";
   $result = $conn->query($sql);

   if ($result->num_rows > 0) {
      // output data of each row
      while ($row = $result->fetch_assoc()) {
         $staff_id = $row["staff_id"];
         $full_names = $row["full_names"];
      }
   }
   ?>

   <h1>Staff Panel</h1>
   <h6 class="text-danger">Name : <?php echo $full_names;  ?> </h6>
   <hr>
   <?php include('staff_nav.php'); ?>


   <div class="container">
      <div class="row">
         <div class="col-md-8">
            <div class="card">
               <div class="card-header">
                  <h4>Apply for Leave</h4>
               </div>
               <?php
   if (isset($_POST['submit'])) {

      $type_of_leave = $_POST['type_of_leave'];
      $description = $_POST['description'];
      $date_from = $_POST['date_from'];
      $date_to = $_POST['date_to'];

      $status = "pending";


      $sql = "INSERT INTO leaves (staff_id, type_of_leave, description, date_to, date_from, status)
      VALUES ('{$staff_id}', '{$type_of_leave}', '{$description}','{$date_from}','{$date_to}','{$status}')";

      if ($conn->query($sql) === TRUE) {
         echo "<p style='background-color:green;' class='text-white p-3'> Application was successfully recorded</p>";
      } else {
         echo "Error: " . $sql . "<br>" . $conn->error;
      }
   }


   ?>
               <div class="card-body">
                  <form action="" method="post">
                     <div class="form-group">
                        <label for="">Type of Leave</label>
                           <input type="text" class="form-control" name="type_of_leave"
                              placeholder="Type of Leave">
                     </div>
                     <div class="form-group">
                        <label for="">Description</label>
                           <textarea class="form-control" name="description" id="" cols="30"
                              rows="3"></textarea>
                     </div>
                     <div class="form-group">
                        <label for="">Date From</label>
                        <input class="form-control" type="date" name="date_from" id="">
                     </div>
                     <div class="form-group">
                     <label for="">Date To</label>
                     <input class="form-control" type="date" name="date_to" id="">
                     </div>
                     <div class="form-group">
                        <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>


      </div>
   </div>

  

</body>

</html>
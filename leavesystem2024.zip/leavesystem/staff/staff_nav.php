<ul class="nav justify-content-center">
   <li class="nav-item">
      <a class="btn btn-outline-danger text-dark m-3" href="index.php">Apply</a>
   </li>
   <li class="nav-item">
      <a class="btn btn-outline-danger text-dark m-3" href="my_leave.php">My Leaves</a>
   </li>
   <li class="nav-item">
      <a class="btn btn-success text-dark m-3" target="_blank" href="../admin">Supervisor</a>
   </li>
</ul>
<?php
include('../includes/header.php');
?>
<style>
   body {
      margin: 150px;
      text-align: center;
      margin-top: 50px;
   }

   .container {
      border-style: solid;
      border-radius: 5px;
      border-color: aqua;
      margin: 50px;
   }

   .row {
      margin: 10px;
   }

   .form {
      margin: 20px;
   }
</style>

<body>
   <div class="container">
      <div class="row">
         <div class="card">
            <div class="card-header">
            <h1>Staff Register</h1>
            </div>
            <?php
if (isset($_POST['submit'])) {
   
    $full_names = mysqli_real_escape_string($conn, $_POST['full_names']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $position = mysqli_real_escape_string($conn, $_POST['position']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
   

    // Prepare the SQL query to insert the data
    $query = "INSERT INTO staff (full_names, username, gender, email, position, password) VALUES ('$full_names', '$username', '$gender', '$email', '$position', '$password')";

    // Execute the query
    $insert_query = mysqli_query($conn, $query);

    // Check if the query was successful
    if ($insert_query) {
        echo "<p style='background-color:green;' class='text-white p-3'> Record was successfully created. You can now login.</p>";
        echo "<a href='../index.php'>Login</a>";
    } else {
        die("<p class='alert alert-danger text-white p-3'> Query failed: " . mysqli_error($conn) . "</p>");
    }
}
?>
            <div class="card-body">
            <form action="" method="post">
                  <div class="form-group">
                     <input type="text" class="form-control" name="full_names" placeholder="Full Names" required>
                  </div>
                  <div class="form-group">
                     <input type="text" class="form-control" name="username" placeholder="Username" required>
                  </div>
                  <div class="form-group">
                     <input type="text" class="form-control" name="gender" placeholder="Gender" required>
                  </div>
                  <div class="form-group">
                     <input type="email" class="form-control" name="email" placeholder="Email" required>
                  </div>
                  <div class="form-group">
                     <input type="text" class="form-control" name="position" placeholder="Position" required>
                  </div>
                  <div class="form-group">
                     <input type="password" class="form-control" name="password" minlength="6" placeholder="Password" required>
                  </div>
                  <div class="form-group">
                     <button class="btn btn-primary" type="submit" name="submit">Submit</button>
                  </div>
            </form>
            </div>
         </div>
      </div>
   </div>


  
  




</body>

</html>
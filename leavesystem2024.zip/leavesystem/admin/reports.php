<?php
include('../includes/header.php');


?>
<style>
   body {
      margin: 150px;
      text-align: center;
      margin-top: 50px;
   }



   .row {
      margin: 10px;
   }

   .form {
      margin: 20px;
   }
</style>

<body>
   <hr>
   <?php include '../includes/nav.php' ?>
   <hr>
   <h1 class="text-center">Reports</h1>

   <div class="container">
      <div class="row">
         <table class="table table-bordered" style="width:100%">
            <tr>
               <th>Leave ID</th>
               <th>Staff ID</th>
               <th>Type of leave</th>
               <th>Description</th>
               <th>Date From</th>
               <th>Date to</th>
               <th>Status</th>
            </tr>
            <?php
            $sql = "SELECT * FROM leaves ORDER BY leave_id DESC";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
               // output data of each row
               while ($row = $result->fetch_assoc()) {
                  $leave_id = $row["leave_id"];
                  $staff_id = $row["staff_id"];
                  $type_of_leave = $row["type_of_leave"];
                  $description = $row["description"];
                  $date_from = $row["date_to"];
                  $date_to = $row["date_to"];
                  $status = $row["status"];

                  // echo $staff_id;

            ?>
                  <tr>
                     <td> <?php echo $leave_id; ?> </td>
                     <td><?php echo $staff_id; ?> </td>
                     <td><?php echo $type_of_leave; ?> </td>
                     <td><?php echo $description; ?> </td>
                     <td><?php echo $date_from;  ?> </td>
                     <td><?php echo $date_to; ?> </td>
                     <?php
                    if ($status === "pending") {
                     echo " <td> <p class='alert alert-warning text-dark'> $status </p> </td>";
                  } elseif ($status === "rejected") {
                     echo " <td> <p class='alert alert-danger text-dark'> $status </p> </td>";
                  }
                  elseif ($status === "cancelled") {
                     echo " <td> <p class='alert alert-info text-dark'> $status </p> </td>";
                  }
                  else {
                     echo " <td> <p class='alert alert-success text-dark'> $status </p> </td>";
                  }

                     ?>

                  </tr>





            <?php

                  // echo "id: " . $row["staff_id"] . " - Name: " . $row["firstname"] . " " . $row["lastname"] . "<br>";
               };
            } else {
               echo "0 results";
            }
            $conn->close();


            ?>

         </table>





      </div>
   </div>


</body>

</html>
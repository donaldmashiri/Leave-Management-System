<?php
include('../includes/header.php');


?>

<?php
         if (isset($_GET['action']) && $_GET['action'] == "approve") {

            $request_id = $_GET['req_id'];
            $approved = "approved";

            $query = "UPDATE leaves SET ";
            $query .= "status  = '{$approved}' ";
            $query .= "WHERE leave_id = {$request_id} ";

            $approve_query = mysqli_query($conn, $query);

            header("Location: view_leaves.php");

            if (!$approve_query) {
               die("Query failed" . mysqli_error($conn));
            }
         }
         ?>


         <?php
         if (isset($_GET['action']) && $_GET['action'] == "reject") {

            $request_id = $_GET['req_id'];

            $rejected = "rejected";

            $query = "UPDATE leaves SET ";
            $query .= "status  = '{$rejected}' ";
            $query .= "WHERE leave_id = {$request_id} ";

            $approve_query = mysqli_query($conn, $query);

            header("Location: view_leaves.php");

            if (!$rejecte_query) {
               die("Query failed" . mysqli_error($conn));
            }
         }
         ?>


<style>
   body {
      margin: 150px;
      text-align: center;
      margin-top: 50px;
   }



   .row {
      margin: 10px;
   }

   .form {
      margin: 20px;
   }
</style>

<body>
   <hr>
   <?php include '../includes/nav.php' ?>
   <hr>
   <h1 class="text-center">Pending Leave application</h1>

   <div class="container">
      <div class="row">
         <?php
         $sql = "SELECT * FROM leaves WHERE status = 'pending'";
         $result = $conn->query($sql);

         if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
               $leave_id = $row["leave_id"];
               $staff_id = $row["staff_id"];
               $type_of_leave = $row["type_of_leave"];
               $description = $row["description"];
               $date_from = $row["date_to"];
               $date_to = $row["date_to"];
               $status = $row["status"];

               // echo $staff_id;

         ?>

               <div class="col-md-6">
                  <div class="card">
                     <div class="card-header">Staff id: 00<?php echo $staff_id; ?></div>
                     <div class="card-body">
                        <h5 class="card-title">Type of Leave</h5>
                        <p class="card-text"><?php echo $type_of_leave; ?></p>
                        <ul class="list-group list-group-flush">
                           <li class="list-group-item"></li>
                           <li class="list-group-item"> <strong>Description: </strong> <?php echo $description; ?></li>
                           <li class="list-group-item">
                              Date from: <?php echo $date_from; ?>
                              Date to: <?php echo $date_to; ?>
                           </li>
                           <li class="list-group-item"> <strong>Status: </strong>
                              <p class="alert alert-info"> <?php echo $status; ?></p>
                           </li>
                        </ul>
                     </div>
                     <div class="card-footer">
                        <form action="" method="get">
                           <a href="view_leaves.php?action=reject&req_id=<?= $leave_id ?>" class="btn btn-danger btn-xs">Reject</a>
                           <a href="view_leaves.php?action=approve&req_id=<?= $leave_id ?>" class="btn btn-success btn-xs">Accept</a>

                        </form>
                     </div>
                  </div>
               </div>

         <?php

            };
         } else {
            echo "<h1 class='alert alert-warning text-center'>No leave applications pending</h1>";
         }



         ?>



   




      </div>
   </div>


</body>

</html>
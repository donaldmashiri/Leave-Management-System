
<?php
include('../includes/header.php');
if (isset($_POST['login'])) {

   $username = $_POST['username'];
   $password = $_POST['password'];

   if ($username === "admin" && $password === "12345") {
      header('Location:view_staff.php');
   }
}

?>
<style>
   body {
      margin: 150px;
      text-align: center;
      margin-top: 50px;
   }

   .container {
      border-style: solid;
      border-radius: 5px;
      border-color: aqua;
      margin: 50px;
   }

   .row {
      margin: 10px;
   }

   .form {
      margin: 20px;
   }
</style>

<body>

   <div class="container">
      <div class="row">
         <h1>Admin Login</h1>
         <form action="" method="post">
            <div class="form">
               <input type="text" name="username" placeholder="username">
            </div>
            <div class="form">
               <input type="password" name="password" placeholder="password">
            </div>
            <div class="form">

               <button type="submit" name="login">Login</button>
            </div>
         </form>
      </div>
   </div>



</body>

</html>
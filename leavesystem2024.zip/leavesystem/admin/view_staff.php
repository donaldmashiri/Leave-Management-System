<?php
include('../includes/header.php');


?>
<style>
   body {
      margin: 150px;
      text-align: center;
      margin-top: 50px;
   }

   

   .row {
      margin: 10px;
   }

   .form {
      margin: 20px;
   }
</style>

<body>
<hr>
   <?php include '../includes/nav.php' ?>
<hr>
   <h1 class="text-center">View Staff Members</h1>

   <div class="container">
      <div class="row">

         <table class="table table-bordered" style="width:100%">
            <tr>
               <th>ID</th>
               <th>Fullnames</th>
               <th>Gender</th>
               <th>Email</th>
               <th>Position</th>
            </tr>
            <?php
            $sql = "SELECT * FROM staff";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
               // output data of each row
               while ($row = $result->fetch_assoc()) {
                  $staff_id = $row["staff_id"];
                  $full_names = $row["full_names"];
                  $gender = $row["gender"];
                  $staff_email = $row["email"];
                  $staff_position = $row["position"];

                  // echo $staff_id;

            ?>
                  <tr>
                     <td> <?php echo $staff_id; ?> </td>
                     <td><?php echo $full_names; ?> </td>
                     <td><?php echo $gender; ?> </td>
                     <td><?php echo $staff_email;  ?> </td>
                     <td><?php echo $staff_position; ?> </td>
                  </tr>





            <?php

                  // echo "id: " . $row["staff_id"] . " - Name: " . $row["firstname"] . " " . $row["lastname"] . "<br>";
               };
            } else {
               echo "0 results";
            }
            $conn->close();


            ?>

         </table>





      </div>
   </div>


</body>

</html>